﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace csc202_6_17_24_GUI
{
    public partial class TBtxFromF1 : Form
    {
        public TBtxFromF1(string from1)

        {
            InitializeComponent();
            textBox1.Text = from1;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            FRM1 FRM1 = new FRM1(textBox1.Text);
            this.Hide();
            FRM1.Show();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnClass_Click(object sender, EventArgs e)
        {
            if (RBFreshman.Checked)
                MessageBox.Show("Welcome to the 9th grade.");

            else if (RBSophmore.Checked)
            {
                MessageBox.Show("Welcome to the 10th grade.");
            }

            else if (RBJunior.Checked)
            {
                MessageBox.Show("Welcome to the 11th grade.");
            }

            else if (RBSenior.Checked)
            {
                MessageBox.Show("Welcome to the 12th grade.");
            }
        }
    }
}
