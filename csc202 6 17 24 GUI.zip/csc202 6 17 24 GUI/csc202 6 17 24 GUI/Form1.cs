﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace csc202_6_17_24_GUI
{
    public partial class FRM1 : Form
    {
        public FRM1(string from2 = "")
        {
            InitializeComponent();
            textBox2.Text = from2;
           
        }

        private void ActionButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Better Days Are Comimg!");
        }

  
        private void Btnf1check_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox2.Text,out int value))
            {
                MessageBox.Show("The integer is Valid");
            }
            else
            {
                MessageBox.Show("Not an Integer!, Please try Again...");
            }
        }

     
       

        
        private void BttNfrm2_Click(object sender, EventArgs e)
        {
            TBtxFromF1 form2 = new TBtxFromF1(textBox1.Text);
            this.Hide();
            form2.Show();

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
          Image dog = Image.FromFile("dog1.jpg");
          pictureBox1.Image = dog;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            Image boa = Image.FromFile("boa.jpg");
            pictureBox1.Image = boa;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }


        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged_1(object sender, EventArgs e)
        {
            Image tigercat = Image.FromFile("tigercat.jpg");
            pictureBox1.Image = tigercat;
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void INTRO_Load(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
