﻿namespace csc202_6_17_24_GUI
{
    partial class TBtxFromF1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.GBoxclass = new System.Windows.Forms.GroupBox();
            this.RBFreshman = new System.Windows.Forms.RadioButton();
            this.RBSophmore = new System.Windows.Forms.RadioButton();
            this.RBJunior = new System.Windows.Forms.RadioButton();
            this.RBSenior = new System.Windows.Forms.RadioButton();
            this.BtnClass = new System.Windows.Forms.Button();
            this.GBoxclass.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(90, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 0;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(90, 38);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 1;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(196, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Return for form1";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(90, 66);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 25);
            this.button1.TabIndex = 3;
            this.button1.Text = "Back to Form1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // GBoxclass
            // 
            this.GBoxclass.Controls.Add(this.RBSenior);
            this.GBoxclass.Controls.Add(this.RBJunior);
            this.GBoxclass.Controls.Add(this.RBSophmore);
            this.GBoxclass.Controls.Add(this.RBFreshman);
            this.GBoxclass.Location = new System.Drawing.Point(380, 22);
            this.GBoxclass.Name = "GBoxclass";
            this.GBoxclass.Size = new System.Drawing.Size(200, 167);
            this.GBoxclass.TabIndex = 4;
            this.GBoxclass.TabStop = false;
            this.GBoxclass.Text = "IndivClasses";
            // 
            // RBFreshman
            // 
            this.RBFreshman.AutoSize = true;
            this.RBFreshman.Location = new System.Drawing.Point(6, 23);
            this.RBFreshman.Name = "RBFreshman";
            this.RBFreshman.Size = new System.Drawing.Size(71, 17);
            this.RBFreshman.TabIndex = 0;
            this.RBFreshman.TabStop = true;
            this.RBFreshman.Text = "Freshman";
            this.RBFreshman.UseVisualStyleBackColor = true;
            // 
            // RBSophmore
            // 
            this.RBSophmore.AutoSize = true;
            this.RBSophmore.Location = new System.Drawing.Point(6, 48);
            this.RBSophmore.Name = "RBSophmore";
            this.RBSophmore.Size = new System.Drawing.Size(73, 17);
            this.RBSophmore.TabIndex = 1;
            this.RBSophmore.TabStop = true;
            this.RBSophmore.Text = "Sophmore";
            this.RBSophmore.UseVisualStyleBackColor = true;
            // 
            // RBJunior
            // 
            this.RBJunior.AutoSize = true;
            this.RBJunior.Location = new System.Drawing.Point(6, 71);
            this.RBJunior.Name = "RBJunior";
            this.RBJunior.Size = new System.Drawing.Size(53, 17);
            this.RBJunior.TabIndex = 2;
            this.RBJunior.TabStop = true;
            this.RBJunior.Text = "Junior";
            this.RBJunior.UseVisualStyleBackColor = true;
            // 
            // RBSenior
            // 
            this.RBSenior.AutoSize = true;
            this.RBSenior.Location = new System.Drawing.Point(6, 94);
            this.RBSenior.Name = "RBSenior";
            this.RBSenior.Size = new System.Drawing.Size(55, 17);
            this.RBSenior.TabIndex = 3;
            this.RBSenior.TabStop = true;
            this.RBSenior.Text = "Senior";
            this.RBSenior.UseVisualStyleBackColor = true;
            // 
            // BtnClass
            // 
            this.BtnClass.Location = new System.Drawing.Point(382, 197);
            this.BtnClass.Name = "BtnClass";
            this.BtnClass.Size = new System.Drawing.Size(75, 23);
            this.BtnClass.TabIndex = 5;
            this.BtnClass.Text = "Process Calss";
            this.BtnClass.UseVisualStyleBackColor = true;
            this.BtnClass.Click += new System.EventHandler(this.BtnClass_Click);
            // 
            // TBtxFromF1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(635, 275);
            this.Controls.Add(this.BtnClass);
            this.Controls.Add(this.GBoxclass);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Name = "TBtxFromF1";
            this.Text = "FormClass";
            this.GBoxclass.ResumeLayout(false);
            this.GBoxclass.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox GBoxclass;
        private System.Windows.Forms.RadioButton RBSophmore;
        private System.Windows.Forms.RadioButton RBFreshman;
        private System.Windows.Forms.RadioButton RBSenior;
        private System.Windows.Forms.RadioButton RBJunior;
        private System.Windows.Forms.Button BtnClass;
    }
}