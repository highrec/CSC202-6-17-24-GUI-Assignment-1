﻿Public Class FRMIntro
    Private Sub FRMIntro_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ButtontoActivate_Click(sender As Object, e As EventArgs) Handles ButtontoActivate.Click

    End Sub
End Class
